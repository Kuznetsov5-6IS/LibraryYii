-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Дек 04 2021 г., 20:00
-- Версия сервера: 10.3.22-MariaDB
-- Версия PHP: 7.2.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `library`
--

-- --------------------------------------------------------

--
-- Структура таблицы `book`
--

CREATE TABLE `book` (
  `id` int(11) NOT NULL,
  `author` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `id_publisher` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `book`
--

INSERT INTO `book` (`id`, `author`, `name`, `id_publisher`) VALUES
(1, 'А.С. Пушкин', 'Евгений Онегин', 4),
(2, 'Марк Твен', 'Приключения Гекльберри Финна', 3),
(3, 'М.А. Булгаков', 'Мастер и Маргарита', 2),
(4, 'Л.Н. Толстой', 'Война и мир', 1),
(5, 'М.Ю. Лермонтов', 'Герой нашего времени', 5),
(6, 'Джек Лондон', 'Белый клык', 6),
(7, 'М.А. Булгаков', 'Белая гвардия', 7),
(8, 'А.Н. Толстой', 'Пётр Первый', 8);

-- --------------------------------------------------------

--
-- Структура таблицы `bookgenre`
--

CREATE TABLE `bookgenre` (
  `id` int(11) NOT NULL,
  `id_genre` int(11) NOT NULL,
  `id_book` int(11) NOT NULL,
  `img` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

--
-- Дамп данных таблицы `bookgenre`
--

INSERT INTO `bookgenre` (`id`, `id_genre`, `id_book`, `img`) VALUES
(1, 3, 4, 'mir.jpg'),
(2, 9, 1, 'onegin.jpg'),
(3, 11, 2, 'adventures.jpg'),
(4, 10, 3, 'margarita.jpg'),
(5, 13, 5, 'geroi.jpg'),
(6, 12, 6, 'klik.jpg'),
(7, 1, 7, 'white.jpg'),
(8, 1, 8, 'petrone.jpg');

-- --------------------------------------------------------

--
-- Структура таблицы `genre`
--

CREATE TABLE `genre` (
  `id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `genre`
--

INSERT INTO `genre` (`id`, `name`) VALUES
(11, 'Детская литература'),
(7, 'Литература модернизма'),
(3, 'Любовный роман'),
(10, 'Мистика'),
(8, 'Оккультная литература'),
(12, 'Повесть'),
(13, 'Психологический роман'),
(1, 'Роман'),
(2, 'Сатира'),
(9, 'Стихи'),
(6, 'Фантастика'),
(4, 'Фарс'),
(5, 'Фэнтези');

-- --------------------------------------------------------

--
-- Структура таблицы `migration`
--

CREATE TABLE `migration` (
  `version` varchar(180) COLLATE utf8mb4_unicode_ci NOT NULL,
  `apply_time` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `migration`
--

INSERT INTO `migration` (`version`, `apply_time`) VALUES
('m000000_000000_base', 1637519896),
('m211121_181754_create_user_table', 1637831102),
('m211121_182844_create_genre_table', 1637831102),
('m211121_182851_create_publisher_table', 1637831102),
('m211121_182856_create_book_table', 1637831102),
('m211121_182912_create_book_genre_table', 1637831102),
('m211121_182912_create_bookgenre_table', 1637832059),
('m211121_182924_create_vidacha_table', 1637831102);

-- --------------------------------------------------------

--
-- Структура таблицы `publisher`
--

CREATE TABLE `publisher` (
  `id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `publisher`
--

INSERT INTO `publisher` (`id`, `name`) VALUES
(3, 'Chatto & Windus'),
(6, 'Macmillan and Company'),
(2, 'издательство «YMCA-Press»'),
(4, 'издательство «Книга»'),
(7, 'Новая Россия'),
(5, 'Отечественные записки'),
(1, 'Русский вестник'),
(8, 'СССР');

-- --------------------------------------------------------

--
-- Структура таблицы `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `birthday` date NOT NULL,
  `username` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lastname` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `firstname` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `admin` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `user`
--

INSERT INTO `user` (`id`, `birthday`, `username`, `password`, `lastname`, `firstname`, `admin`) VALUES
(1, '2000-01-01', 'admin', 'admin', 'admin', 'admin', 1),
(2, '2003-11-28', 'timur', 'timur', 'Кузнецов', 'Тимур', 0);

-- --------------------------------------------------------

--
-- Структура таблицы `vidacha`
--

CREATE TABLE `vidacha` (
  `id` int(11) NOT NULL,
  `id_book` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `start_date` date NOT NULL DEFAULT current_timestamp(),
  `must_finish_date` date NOT NULL,
  `fact_finish_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `book`
--
ALTER TABLE `book`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx-book-id_publisher` (`id_publisher`);

--
-- Индексы таблицы `bookgenre`
--
ALTER TABLE `bookgenre`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx-bookgenre-id_genre` (`id_genre`),
  ADD KEY `idx-bookgenre-id_book` (`id_book`);

--
-- Индексы таблицы `genre`
--
ALTER TABLE `genre`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Индексы таблицы `migration`
--
ALTER TABLE `migration`
  ADD PRIMARY KEY (`version`);

--
-- Индексы таблицы `publisher`
--
ALTER TABLE `publisher`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Индексы таблицы `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `vidacha`
--
ALTER TABLE `vidacha`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx-vidacha-id_book` (`id_book`),
  ADD KEY `idx-vidacha-id_user` (`id_user`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `book`
--
ALTER TABLE `book`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT для таблицы `bookgenre`
--
ALTER TABLE `bookgenre`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT для таблицы `genre`
--
ALTER TABLE `genre`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT для таблицы `publisher`
--
ALTER TABLE `publisher`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT для таблицы `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT для таблицы `vidacha`
--
ALTER TABLE `vidacha`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `book`
--
ALTER TABLE `book`
  ADD CONSTRAINT `fk-book-id_publisher` FOREIGN KEY (`id_publisher`) REFERENCES `publisher` (`id`);

--
-- Ограничения внешнего ключа таблицы `bookgenre`
--
ALTER TABLE `bookgenre`
  ADD CONSTRAINT `fk-bookgenre-id_book` FOREIGN KEY (`id_book`) REFERENCES `book` (`id`),
  ADD CONSTRAINT `fk-bookgenre-id_genre` FOREIGN KEY (`id_genre`) REFERENCES `genre` (`id`);

--
-- Ограничения внешнего ключа таблицы `vidacha`
--
ALTER TABLE `vidacha`
  ADD CONSTRAINT `fk-vidacha-id_book` FOREIGN KEY (`id_book`) REFERENCES `book` (`id`),
  ADD CONSTRAINT `fk-vidacha-id_user` FOREIGN KEY (`id_user`) REFERENCES `user` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
